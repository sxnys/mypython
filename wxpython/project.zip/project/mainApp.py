# coding: utf-8

import wx
# import Frame1
import mainFrame
from extra import JsonIO

class MainApp(wx.App):
    def OnInit(self):
        self.frame = mainFrame.MainWindow(None, u'项目申报')
        self.frame.Show()
        # print JsonIO.getNewJsonDict()
        return True

if __name__ == '__main__':
    app = MainApp()
    app.MainLoop()