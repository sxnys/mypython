# -*- coding: utf-8
__author__ = 'Sxn'
__date__ = '2017/5/19 18:19'


''' 主窗口，包含标签页和菜单
'''

import wx
from panels import DeclarationInfo, ApplicantInfo, StudyResults, Studying, StudyExperience, WorkExperience, DefenseProject, Management, TechnologyAwards, Parent


class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(1200,800))

        # self.SetMaxSize((1200, 800))

        # 创建位于窗口底部的状态栏
        self.CreateStatusBar()

        panel = wx.Panel(self)

        self.gSizer = wx.BoxSizer(wx.VERTICAL)

        img = wx.Image('bglogo.jpg', wx.BITMAP_TYPE_ANY)
        sz = self.GetClientSize()
        img = img.Scale(sz.x * 1.7, sz.y / 5)
        # w = img.GetWidth()
        # h = img.GetHeight()
        # img = img.Scale(w / 5, h / 15)

        sb1 = wx.StaticBitmap(panel, -1, wx.Bitmap(img))
        self.gSizer.Add(sb1, 1, wx.ALIGN_CENTER)


        # 布置标签面板
        notebook = wx.Notebook(panel, size=(2100, 1600))
        declaration_panel = DeclarationInfo.TabPanel(notebook)
        applicant_panel = ApplicantInfo.TabPanel(notebook)
        studyResults_panel = StudyResults.TabPanel(notebook)
        studying_panel = Studying.TabPanel(notebook)
        studyExperience_panel = StudyExperience.TabPanel(notebook)
        workExperience_panel = WorkExperience.TabPanel(notebook)
        defenseProject_panel = DefenseProject.TabPanel(notebook)
        management_panel = Management.TabPanel(notebook)
        technologyAwards_panel = TechnologyAwards.TabPanel(notebook)
        parent_panel = Parent.TabPanel(notebook)

        notebook.AddPage(declaration_panel, declaration_panel.getTabName())
        notebook.AddPage(applicant_panel, applicant_panel.getTabName())
        notebook.AddPage(studyResults_panel, studyResults_panel.getTabName())
        notebook.AddPage(studying_panel, studying_panel.getTabName())
        notebook.AddPage(studyExperience_panel, studyExperience_panel.getTabName())
        notebook.AddPage(workExperience_panel, workExperience_panel.getTabName())
        notebook.AddPage(defenseProject_panel, defenseProject_panel.getTabName())
        notebook.AddPage(management_panel, management_panel.getTabName())
        notebook.AddPage(technologyAwards_panel, technologyAwards_panel.getTabName())
        notebook.AddPage(parent_panel, parent_panel.getTabName())

        self.gSizer.Add(notebook, 10, wx.ALIGN_CENTER)

        panel.SetSizerAndFit(self.gSizer)
        self.Fit()

        # 设置菜单
        fileMenu = wx.Menu()
        exportJson = fileMenu.Append(wx.ID_OPEN, u'导出Json文件', u'导出填写的项目申报书对应的Json文件')
        exportWord = fileMenu.Append(wx.ID_OPEN, u'导出word', u'导出一个项目申报书的文档')
        printBook = fileMenu.Append(wx.ID_PRINT, u'打印', u'打印项目申报书')
        fileMenu.AppendSeparator()
        menuExit = fileMenu.Append(wx.ID_EXIT, u'退出', u'终止应用程序')

        # 创建菜单栏
        menuBar = wx.MenuBar()
        menuBar.Append(fileMenu, u'文件')
        self.SetMenuBar(menuBar)

