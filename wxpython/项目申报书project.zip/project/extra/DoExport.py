# -*- coding: utf-8
__author__ = 'Sxn'
__date__ = '2017/5/24 12:32'


import JsonIO
from JsonIO import JsonDict
import json
import docx
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT


def exportJson():
    COMFIRM = reduce(lambda x, y: x and y, JsonIO.isConfirm)
    # print COMFIRM
    if COMFIRM == False:
        return COMFIRM
        # pass

    # 封面
    if JsonIO.cover_dep_recommend['type'] == u'单位推荐':
        JsonIO.JsonDict['cover'] = JsonIO.cover_dep_recommend
    else:
        JsonIO.JsonDict['cover'] = JsonIO.cover_expert_nomination

    # 申请人基本信息
    JsonIO.JsonDict['basic_info']['personal_info'] = JsonIO.personal_info
    JsonIO.JsonDict['basic_info']['dep_info'] = JsonIO.dep_info

    # 主要研究成果
    JsonIO.JsonDict['research_result'] = JsonIO.research_result

    # 拟展开的研究工作及其军事意义
    JsonIO.JsonDict['work_and_significance'] = JsonIO.work_and_significance

    # 学习经历
    JsonIO.JsonDict['personal_profile']['learning_exp'] = JsonIO.learning_exp

    # 工作经历
    JsonIO.JsonDict['personal_profile']['working_exp'] = JsonIO.working_exp

    # 承担国防相关代表性项目情况
    JsonIO.JsonDict['personal_profile']['projects_info'] = JsonIO.projects_info

    # 代表性成果
    JsonIO.JsonDict['personal_profile']['repr_results_to_word'] = JsonIO.repr_results_to_word

    # 重要科技奖项情况
    JsonIO.JsonDict['personal_profile']['awards'] = JsonIO.awards

    # 发明专利、国防专利情况
    JsonIO.JsonDict['personal_profile']['patent'] = JsonIO.patent

    JsonOutput = json.dumps(JsonIO.JsonDict)
    JsonOutFile = open('output.json', 'w')
    JsonOutFile.write(JsonOutput)

    return True


def exportWord():
    isJsonFinish = exportJson()

    if isJsonFinish == False:
        return isJsonFinish

    doc = Document()

    # 标题字体
    style = doc.styles['Caption']
    style.font.bold = True
    style.font.size = Pt(24)

    # 段落标题字体
    style = doc.styles['Normal']
    style.font.bold = True
    style.font.size = Pt(14)
    # 段落标题括号内容字体
    style = doc.styles['Body Text 3']
    style.font.bold = False
    style.font.size = Pt(14)
    # 填写内容字体
    style = doc.styles['Body Text']     # paragraph
    style.font.bold = False
    style.font.size = Pt(12)

    style = doc.styles['Body Text Char']    # character
    style.font.bold = False
    style.font.size = Pt(12)
    # 段落中的注释字体
    style = doc.styles['Body Text 2']
    style.font.bold = False
    style.font.size = Pt(10)

    ''' 封面
    '''
    title = u'国防科技卓越青年人才基金项目申报书'
    doc.add_paragraph('\n\n')
    paraTitle = doc.add_paragraph(title, style = doc.styles['Caption'])
    doc.add_paragraph('\n' * 4)
    paraTitle.alignment = WD_ALIGN_PARAGRAPH.CENTER

    label1 = u'\t\t\t申 报 类 型：\t'
    label2 = u'\t\t\t申    请   人：\t'
    label3 = u'\t\t\t项 目 名 称：\t'
    label4 = u'\t\t\t申 报 领 域：\t'
    label5 = u'\t\t\t工 作 单 位：\t'
    label6 = u'\t\t\t联 系 电 话：\t'
    label7 = u'\t\t\t专 家 提 名：\t'

    type = doc.add_paragraph(label1, style = doc.styles['Normal'])
    typeRun = type.add_run(text=JsonDict['cover']['type'])
    typeRun.bold = False
    typeRun.font.size = Pt(12)

    applicant = doc.add_paragraph(label2, style = doc.styles['Normal'])
    applicantRun = applicant.add_run(JsonDict['cover']['applicant'])
    applicantRun.bold = False
    applicantRun.font.size = Pt(12)

    project_name = doc.add_paragraph(label3, style = doc.styles['Normal'])
    project_nameRun = project_name.add_run(JsonDict['cover']['project_name'])
    project_nameRun.bold = False
    project_nameRun.font.size = Pt(12)

    application_field = doc.add_paragraph(label4, style = doc.styles['Normal'])
    application_fieldRun = application_field.add_run(JsonDict['cover']['application_field'])
    application_fieldRun.bold = False
    application_fieldRun.font.size = Pt(12)

    working_dep = doc.add_paragraph(label5, style = doc.styles['Normal'])
    working_depRun = working_dep.add_run(JsonDict['cover']['working_dep'])
    working_depRun.bold = False
    working_depRun.font.size = Pt(12)

    telephone = doc.add_paragraph(label6, style = doc.styles['Normal'])
    telephoneRun = telephone.add_run(JsonDict['cover']['telephone'])
    telephoneRun.bold = False
    telephoneRun.font.size = Pt(12)

    if JsonDict['cover']['type'] == u'专家提名':
        extra = doc.add_paragraph(label7, style=doc.styles['Normal'])
        extraRun = extra.add_run(JsonDict['cover']['expert'])
        extraRun.bold = False
        extraRun.font.size = Pt(12)

    buttom = doc.add_paragraph('\n' * 11)
    zyjw = buttom.add_run(u'中 央 军 委 科 学 技 术 委 员 会 制\n')
    zyjw.bold = False
    zyjw.font.size = Pt(14)
    finishDate = buttom.add_run(u'二〇一七年%s月%s日' % (' ' * 8, ' ' * 8))
    finishDate.bold = False
    finishDate.font.size = Pt(14)
    buttom.alignment = WD_ALIGN_PARAGRAPH.CENTER


    doc.add_section(start_type=1)
    ''' 一、申请人基本信息
    '''
    baseInfo_title = doc.add_paragraph(u'一、申请人基本信息', style=doc.styles['Normal'])
    baseInfo = doc.add_table(rows=8, cols=7)

    baseInfo.cell(2, 0).text = u'申请人情况'
    baseInfo.cell(0, 0).merge(baseInfo.cell(1, 0)).merge(baseInfo.cell(2, 0)).merge(baseInfo.cell(3, 0)).merge(baseInfo.cell(4, 0))

    baseInfo.cell(0, 1).text = u'姓 名'
    baseInfo.cell(0, 2).text = JsonDict['basic_info']['personal_info']['name']
    baseInfo.cell(0, 3).text = u'性 别'
    baseInfo.cell(0, 4).text = JsonDict['basic_info']['personal_info']['gender']
    baseInfo.cell(0, 5).text = u'出生年月'
    baseInfo.cell(0, 6).text = JsonDict['basic_info']['personal_info']['birthday']

    baseInfo.cell(1, 1).text = u'学 位'
    baseInfo.cell(1, 2).text = JsonDict['basic_info']['personal_info']['bachelor']
    baseInfo.cell(1, 3).text = u'职 称'
    baseInfo.cell(1, 4).text = JsonDict['basic_info']['personal_info']['job']
    baseInfo.cell(1, 5).text = u'单位职务'
    baseInfo.cell(1, 6).text = JsonDict['basic_info']['personal_info']['dep_job']

    baseInfo.cell(2, 1).text = u'主要研究方向'
    baseInfo.cell(2, 2).text = JsonDict['basic_info']['personal_info']['research']
    baseInfo.cell(2, 2).merge(baseInfo.cell(2, 3)).merge(baseInfo.cell(2, 4)).merge(baseInfo.cell(2, 5)).merge(baseInfo.cell(2, 6))

    baseInfo.cell(3, 1).text = u'身份证件名称'
    baseInfo.cell(3, 2).text = JsonDict['basic_info']['personal_info']['id_name']
    baseInfo.cell(3, 3).text = u'证件编号'
    baseInfo.cell(3, 4).text = JsonDict['basic_info']['personal_info']['id_num']
    baseInfo.cell(3, 4).merge(baseInfo.cell(3, 5)).merge(baseInfo.cell(3, 6))

    baseInfo.cell(4, 1).text = u'办公电话'
    baseInfo.cell(4, 2).text = JsonDict['basic_info']['personal_info']['office_phone']
    baseInfo.cell(4, 3).text = u'手 机'
    baseInfo.cell(4, 4).text = JsonDict['basic_info']['personal_info']['telephone']
    baseInfo.cell(4, 5).text = 'E-mail'
    baseInfo.cell(4, 6).text = JsonDict['basic_info']['personal_info']['email']

    baseInfo.cell(5, 0).text = u'申请单位情况'
    baseInfo.cell(5, 0).merge(baseInfo.cell(6, 0))

    baseInfo.cell(5, 1).text = u'单位名称'
    baseInfo.cell(5, 2).text = JsonDict['basic_info']['dep_info']['dep_name']
    baseInfo.cell(5, 2).merge(baseInfo.cell(5, 3))
    baseInfo.cell(5, 4).text = u'联系人（手机）'
    baseInfo.cell(5, 4).merge(baseInfo.cell(5, 5))
    baseInfo.cell(5, 6).text = JsonDict['basic_info']['dep_info']['telephone']

    baseInfo.cell(6, 1).text = u'通信地址'
    baseInfo.cell(6, 2).text = JsonDict['basic_info']['dep_info']['address']
    baseInfo.cell(6, 2).merge(baseInfo.cell(6, 3)).merge(baseInfo.cell(6, 4)).merge(baseInfo.cell(6, 5)).merge(baseInfo.cell(6, 6))

    baseInfo.cell(7, 0).text = u'''
        本人保证所填写的信息均真实有效，无任何虚假信息。本人完全清楚本声明的法律后果，如有不实，愿意承担相应的法律责任。\n
        %s项目申请人签字：
        %s\t\t年\t月\t日
    ''' % ('\t'*18, '\t'*18)
    # baseInfo.cell(7, 0).merge(baseInfo.cell(7, 1)).merge(baseInfo.cell(7, 2)).merge(baseInfo.cell(7, 3)).merge(baseInfo.cell(7, 4)).merge(baseInfo.cell(7, 5)).merge(baseInfo.cell(7, 6))

    reduce(lambda x, y: x.merge(y), [baseInfo.cell(7, i) for i in xrange(7)])

    doc.add_paragraph('\n')

    ''' 二、主要研究成果（2000字内）
    '''
    research_result_title = doc.add_paragraph(u'二、主要研究成果', style=doc.styles['Normal'])
    research_result_titleRun = research_result_title.add_run(u'（2000字内）')
    research_result_titleRun.bold = False
    research_result_instruct = u'\t着重阐述近5年来在国防科技领域取得的代表性研究成果，如在国防基础研究领域取得重大发现，在工程研究领域突破重大技术瓶颈，在重要型号研制中攻克关键技术难题，或转化应用生产重大军事效益。'
    doc.add_paragraph(research_result_instruct, style=doc.styles['Body Text 2'])
    research_result = doc.add_paragraph(JsonDict['research_result'] + '\n', style=doc.styles['Body Text'])

    doc.add_paragraph('\n')

    ''' 三、拟展开的研究工作及其军事意义（2000字内）
    '''
    work_and_significance_title = doc.add_paragraph(u'三、拟展开的研究工作及其军事意义', style=doc.styles['Normal'])
    work_and_significance_titleRun = work_and_significance_title.add_run(u'（2000字内）')
    work_and_significance_titleRun.bold = False
    work_and_significance_instruct = u'\t着重阐述拟展开的研究工作的创新构思，主要研究方向和初步研究方案，及其军事意义和应用前景。'
    doc.add_paragraph(work_and_significance_instruct, style=doc.styles['Body Text 2'])
    work_and_significance = doc.add_paragraph(JsonDict['work_and_significance'] + '\n', style=doc.styles['Body Text'])

    doc.add_paragraph('\n')

    ''' 四、个人简介
    '''
    personal_profile = doc.add_paragraph(u'四、个人简介', style=doc.styles['Normal'])

    ''' （一）学习经历（从大学教育填起）
    '''
    learning_exp_title = doc.add_paragraph(u'（一）学习经历', style=doc.styles['Normal'])
    learning_exp_titleRun = learning_exp_title.add_run(u'（从大学教育填起）')
    learning_exp_titleRun.bold = False

    learning_exp_number = len(JsonDict['personal_profile']['learning_exp'])
    learning_exp = doc.add_table(rows=learning_exp_number + 1, cols=4, style = 'Table Grid')
    learning_exp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    learning_exp.style.font.size = Pt(12)
    learning_exp.style.font.bold = False

    learning_exp.cell(0, 0).text = u'起止年月'
    learning_exp.cell(0, 1).text = u'校（院）及系名称'
    learning_exp.cell(0, 2).text = u'专业'
    learning_exp.cell(0, 3).text = u'学位'
    for i in xrange(1, learning_exp_number + 1):
        learning_exp.cell(i, 0).text = JsonDict['personal_profile']['learning_exp'][i-1]['start_end_date']
        # learning_exp.cell(i, 0).alignment = WD_TABLE_ALIGNMENT.CENTER
        learning_exp.cell(i, 1).text = JsonDict['personal_profile']['learning_exp'][i-1]['school_name']
        learning_exp.cell(i, 2).text = JsonDict['personal_profile']['learning_exp'][i-1]['major_subject']
        learning_exp.cell(i, 3).text = JsonDict['personal_profile']['learning_exp'][i-1]['bachelor']

    doc.add_paragraph('\n')

    ''' （二）工作经历（含学术兼职情况）
    '''
    working_exp_title = doc.add_paragraph(u'（二）工作经历', style=doc.styles['Normal'])
    working_exp_titleRun = working_exp_title.add_run(u'（含学术兼职情况）')
    working_exp_titleRun.bold = False

    working_exp_number = len(JsonDict['personal_profile']['working_exp'])
    working_exp = doc.add_table(rows=working_exp_number + 1, cols=3, style='Table Grid')
    working_exp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    working_exp.style.font.size = Pt(12)
    working_exp.style.font.bold = False

    working_exp.cell(0, 0).text = u'起止年月'
    working_exp.cell(0, 1).text = u'工作单位'
    working_exp.cell(0, 2).text = u'职务/职称'
    for i in xrange(1, working_exp_number + 1):
        working_exp.cell(i, 0).text = JsonDict['personal_profile']['working_exp'][i - 1]['start_end_date']
        working_exp.cell(i, 1).text = JsonDict['personal_profile']['working_exp'][i - 1]['working_dep']
        working_exp.cell(i, 2).text = JsonDict['personal_profile']['working_exp'][i - 1]['job']

    doc.add_paragraph('\n')

    ''' （三）承担国防相关代表性项目情况（限5项）
    '''
    projects_info_title = doc.add_paragraph(u'（三）承担国防相关代表性项目情况', style=doc.styles['Normal'])
    projects_info_titleRun = projects_info_title.add_run(u'（限5项）')
    projects_info_titleRun.bold = False

    projects_info_number = len(JsonDict['personal_profile']['projects_info'])
    projects_info = doc.add_table(rows=projects_info_number + 1, cols=7, style='Table Grid')
    projects_info.alignment = WD_ALIGN_PARAGRAPH.CENTER
    projects_info.style.font.size = Pt(12)
    projects_info.style.font.bold = False

    projects_info.cell(0, 0).text = u'序号'
    projects_info.cell(0, 1).text = u'起止年月'
    projects_info.cell(0, 2).text = u'名称'
    projects_info.cell(0, 3).text = u'来源'
    projects_info.cell(0, 4).text = u'经费'
    projects_info.cell(0, 5).text = u'本人承担任务'
    projects_info.cell(0, 6).text = u'本人排序'
    for i in xrange(1, projects_info_number + 1):
        projects_info.cell(i, 0).text = JsonDict['personal_profile']['projects_info'][i - 1]['id']
        projects_info.cell(i, 1).text = JsonDict['personal_profile']['projects_info'][i - 1]['start_end_date']
        projects_info.cell(i, 2).text = JsonDict['personal_profile']['projects_info'][i - 1]['project_name']
        projects_info.cell(i, 3).text = JsonDict['personal_profile']['projects_info'][i - 1]['source']
        projects_info.cell(i, 4).text = JsonDict['personal_profile']['projects_info'][i - 1]['fund']
        projects_info.cell(i, 5).text = JsonDict['personal_profile']['projects_info'][i - 1]['mission']
        projects_info.cell(i, 6).text = JsonDict['personal_profile']['projects_info'][i - 1]['sort']

    doc.add_paragraph('\n')

    ''' （四）代表性成果（论文、著作、研究技术报告、重要学术会议邀请报告，10篇以内第一作者或通信作者，按照重要性排序。每篇应说明申请人的主要贡献，包括：提出的学术思想、创造性、学术刊物中的主要引用及评价情况等。填写顺序：论文、著作、研究技术报告、重要学术会议邀请报告）
    '''
    working_exp_title = doc.add_paragraph(u'（四）代表性成果', style=doc.styles['Normal'])
    working_exp_titleRun = working_exp_title.add_run(u'（论文、著作、研究技术报告、重要学术会议邀请报告，10篇以内第一作者或通信作者，按照重要性排序。每篇应说明申请人的主要贡献，包括：提出的学术思想、创造性、学术刊物中的主要引用及评价情况等。填写顺序：论文、著作、研究技术报告、重要学术会议邀请报告）')
    working_exp_titleRun.bold = False
    doc.add_paragraph(u'填写顺序：', style=doc.styles['Body Text 2'])
    doc.add_paragraph(u'\t论文：作者（按原排序），题目，期刊名称，卷（期）（年），起止页码；', style=doc.styles['Body Text 2'])
    doc.add_paragraph(u'\t著作：作者（按原排序），著作名称，出版社，出版年份，出版地；', style=doc.styles['Body Text 2'])
    doc.add_paragraph(u'\t研究技术报告（未公开发表的重要报告）：作者（按原排序），报告题目，完成年份；', style=doc.styles['Body Text 2'])
    doc.add_paragraph(u'\t重要学术会议邀请报告：作者（按原排序），报告题目，报告年份，会议名称，地点；', style=doc.styles['Body Text 2'])

    repr_results_to_word_number = len(JsonDict['personal_profile']['repr_results_to_word'])
    repr_results_to_word = doc.add_table(rows=repr_results_to_word_number * 2 + 1, cols=2, style='Table Grid')
    repr_results_to_word.cell(0, 0).text = u'序号'
    repr_results_to_word.cell(0, 1).text = u'代表性论文、著作（包括教材）、研究技术报告、重要学术会议邀请报告'

    for i in xrange(1, repr_results_to_word_number + 1):
        repr_results_to_word.cell(i * 2 - 1, 0).text = str(i)
        repr_results_to_word.cell(i * 2 - 1, 1).text = JsonDict['personal_profile']['repr_results_to_word'][i - 1]['management']
        repr_results_to_word.cell(i * 2, 1).text = u'主要贡献及引用评价情况：' + JsonDict['personal_profile']['repr_results_to_word'][i - 1]['contribution_refs_info']

        repr_results_to_word.cell(i * 2 - 1, 0).merge(repr_results_to_word.cell(i * 2, 0))

    doc.add_paragraph('\n')

    ''' （五）重要科技奖项情况（10项以内）
    '''
    awards_title = doc.add_paragraph(u'（五）重要科技奖项情况', style=doc.styles['Normal'])
    awards_titleRun = awards_title.add_run(u'（10项以内）')
    awards_titleRun.bold = False
    doc.add_paragraph(u'\t按顺序填写全部获奖人姓名（按原顺序）；获奖项目名称；获奖年份、类别及等级（如1999年国家自然科学二等奖，1998年军队科技进步一等奖等），并分别阐述申请人的主要贡献（限100字）。', style=doc.styles['Body Text 2'])

    awards_number = len(JsonDict['personal_profile']['awards'])
    awards = doc.add_table(rows=awards_number * 2 + 1, cols=2, style='Table Grid')
    awards.cell(0, 0).text = u'序号'
    awards.cell(0, 1).text = u'重要科技奖项'

    for i in xrange(1, awards_number + 1):
        awards.cell(i * 2 - 1, 0).text = str(i)
        awards.cell(i * 2 - 1, 1).text = u'全部获奖人：%s\t获奖项目：%s\t奖项：%s' \
            % (JsonDict['personal_profile']['awards'][i - 1]['person_name'],
               JsonDict['personal_profile']['awards'][i - 1]['project_name'],
               JsonDict['personal_profile']['awards'][i - 1]['year'] +
                    JsonDict['personal_profile']['awards'][i - 1]['category'] +
                    JsonDict['personal_profile']['awards'][i - 1]['rank']
               )
        awards.cell(i * 2, 1).text = u'主要贡献：' + JsonDict['personal_profile']['awards'][i - 1]['contribution']

        awards.cell(i * 2 - 1, 0).merge(awards.cell(i * 2, 0))

    doc.add_paragraph('\n')

    ''' （六）发明专利、国防专利情况（10项以内）
    '''
    patent_title = doc.add_paragraph(u'（六）发明专利、国防专利情况', style=doc.styles['Normal'])
    patent_titleRun = patent_title.add_run(u'（10项以内）')
    patent_titleRun.bold = False
    doc.add_paragraph(u'\t请按顺序填写专利申报人（按原排序）；专利名称；申请年份、申请号；批准年份、专利号。并分别简述专利实施情况和申请人在专利发明和实施中的主要贡献（100字以内）。',
                      style=doc.styles['Body Text 2'])

    patent_number = len(JsonDict['personal_profile']['patent'])
    patent = doc.add_table(rows=patent_number * 2 + 1, cols=2, style='Table Grid')
    patent.cell(0, 0).text = u'序号'
    patent.cell(0, 1).text = u'发明专利情况'

    for i in xrange(1, patent_number + 1):
        patent.cell(i * 2 - 1, 0).text = str(i)
        patent.cell(i * 2 - 1, 1).text = u'专利申报人：%s\t专利名称：%s\t申请年份：%s\t申请号：%s\t批准年份：%s\t专利号：%s' \
                                         % (JsonDict['personal_profile']['patent'][i - 1]['person_name'],
                                            JsonDict['personal_profile']['patent'][i - 1]['patent_name'],
                                            JsonDict['personal_profile']['patent'][i - 1]['year'],
                                            JsonDict['personal_profile']['patent'][i - 1]['application_num'],
                                            JsonDict['personal_profile']['patent'][i - 1]['approved_year'],
                                            JsonDict['personal_profile']['patent'][i - 1]['patent_num']
                                            )
        patent.cell(i * 2, 1).text = u'主要贡献及专利实施情况：' + JsonDict['personal_profile']['patent'][i - 1]['contribution_conduct']

        patent.cell(i * 2 - 1, 0).merge(patent.cell(i * 2, 0))

    doc.add_paragraph('\n')

    ''' 五、单位审核
    '''
    check_title = doc.add_paragraph(u'五、单位审核', style=doc.styles['Normal'])

    check = doc.add_table(rows=2, cols=2, style='Table Grid')
    check.cell(0, 0).text = u'\n\t单位针对申报书真实性审核意见：' + '\n' * 12
    check.cell(1, 1).text = u'''
        %s单位负责人签字：
        %s  （单位公章）
        %s          \t年\t月\t日
    ''' % ('\t' * 7, '\t' * 7, '\t' * 7)

    newCell1 = check.cell(0, 0).merge(check.cell(0, 1))
    newCell2 = check.cell(1, 0).merge(check.cell(1, 1))
    newCell1.merge(newCell2)


    doc.save(u'项目申报书.docx')

    return True
