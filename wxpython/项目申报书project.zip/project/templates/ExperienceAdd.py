# -*- coding: utf-8
__author__ = 'Sxn'
__date__ = '2017/5/21 17:26'


'''个人经历方面的信息（学习经历、工作经历、承担国防相关代表性项目情况）添加的模板类
'''

import wx
import wx.grid
from extra import JsonIO


class TabPanel(wx.Panel):
    def __init__(self, parent, tabName, instructText, numLimit, editInfo, colSize, childOrder = 1):
        wx.Panel.__init__(self, parent)
        self.tabName = tabName

        self.childOrder = childOrder       # 标记是第几个子类

        self.editObject = list()
        self.isConfirm = False

        self.info = {}  # 表格某一行数据

        self.editInfo = editInfo
        self.numLimit = numLimit

        self.vSizer = wx.BoxSizer(wx.VERTICAL)
        # self.grid = wx.GridBagSizer(hgap=0, vgap=0)

        self.font = wx.Font(12, wx.SWISS, wx.NORMAL, wx.BOLD)
        self.titleFont = wx.Font(24, wx.MODERN, wx.NORMAL, wx.BOLD)
        self.instructFont = wx.Font(12, wx.MODERN, wx.NORMAL, wx.NORMAL)
        self.editFont = wx.Font(12, wx.SWISS, wx.NORMAL, wx.NORMAL)
        self.editLinkFont = wx.Font(12, wx.MODERN, wx.NORMAL, wx.BOLD)
        self.SetFont(self.font)

        self.title = wx.StaticText(self, label=self.tabName)
        self.title.SetFont(self.titleFont)

        self.instructText = instructText
        self.instruct = wx.StaticText(self, label=self.instructText)
        self.instruct.SetFont(self.instructFont)

        '''处理表格
        '''
        self.panel = wx.Panel(self)
        self.infoLabelNum = len(editInfo)
        self.infoGrid = wx.grid.Grid(self)
        self.gridRow = 0
        self.gridCol = self.infoLabelNum
        self.infoGrid.CreateGrid(self.gridRow, self.gridCol + 2)
        for col in xrange(self.gridCol):
            self.infoGrid.SetColLabelValue(col, editInfo[col])
            self.infoGrid.SetColSize(col, colSize[col])
        # self.infoGrid.SetDefaultColSize(250)
        self.infoGrid.SetDefaultRowSize(30)
        self.infoGrid.SetDefaultCellFont(self.editFont)
        self.infoGrid.SetDefaultCellAlignment(wx.CENTRE, wx.CENTRE)

        # 设置编辑操作的列
        self.infoGrid.SetColLabelValue(self.gridCol, u'操作1')
        self.infoGrid.SetColSize(self.gridCol, 40)
        # 设置删除操作的列
        self.infoGrid.SetColLabelValue(self.gridCol + 1, u'操作2')
        self.infoGrid.SetColSize(self.gridCol + 1, 40)
        self.infoGrid.Bind(wx.grid.EVT_GRID_CELL_LEFT_CLICK, self.OnGridOperation)

        self.infoGrid.EnableEditing(False)
        # print self.infoGrid.GetDefaultCellAlignment()

        '''按钮
        '''
        self.addButton = wx.Button(self, label=u'添加')
        self.confirmButton = wx.Button(self, label=u'确定')
        self.editButton = wx.Button(self, label=u'编辑')
        self.addButton.SetFont(self.editFont)
        self.confirmButton.SetFont(self.editFont)
        self.editButton.SetFont(self.editFont)
        self.Bind(wx.EVT_BUTTON, self.OnAdd, self.addButton)
        self.Bind(wx.EVT_BUTTON, self.OnConfirm, self.confirmButton)
        self.Bind(wx.EVT_BUTTON, self.OnEdit, self.editButton)
        self.hSizer1 = wx.BoxSizer(wx.HORIZONTAL)
        self.hSizer1.Add(self.addButton, 0, wx.ALIGN_CENTER)
        self.hSizer1.Add(wx.StaticText(self, size=(100, -1)), 0, wx.ALIGN_CENTER)
        self.hSizer1.Add(self.confirmButton, 0, wx.ALIGN_CENTER)
        self.hSizer1.Add(wx.StaticText(self, size=(100, -1)), 0, wx.ALIGN_CENTER)
        self.hSizer1.Add(self.editButton, 0, wx.ALIGN_CENTER)

        '''整体布局
        '''
        self.vSizer.Add((0, 0), 1)
        self.vSizer.Add(self.title, 1, wx.ALIGN_CENTER)
        self.vSizer.Add(self.instruct, 1, wx.ALIGN_CENTER)
        self.vSizer.Add(self.infoGrid, 6, wx.ALIGN_CENTER)
        self.vSizer.Add(self.hSizer1, 1, wx.ALIGN_CENTER)

        self.SetSizerAndFit(self.vSizer)

    def getTabName(self):
        return self.tabName

    def addResult(self, addDialog):
        if addDialog.ShowModal() == wx.ID_OK:
            self.info = addDialog.getInfo()
            self.infoGrid.AppendRows()
            for i in xrange(self.gridCol):
                self.infoGrid.SetCellValue(self.gridRow, i, self.info[self.editInfo[i]])
            self.infoGrid.SetCellValue(self.gridRow, self.gridCol, u'编辑')
            self.infoGrid.SetCellValue(self.gridRow, self.gridCol + 1, u'删除')
            self.infoGrid.SetCellFont(self.gridRow, self.gridCol, self.editLinkFont)
            self.infoGrid.SetCellFont(self.gridRow, self.gridCol + 1, self.editLinkFont)
            self.gridRow += 1

    def OnAdd(self, event):
        if self.isConfirm:
            pass
        elif self.gridRow == self.numLimit:
            dlg = wx.MessageDialog(self, u'最多添加' + str(self.numLimit) + u'项！', u'提示', wx.OK)
            dlg.ShowModal()
            dlg.Destroy()
        else:
            # 添加弹窗
            addDialog = AddDialog(self, u'添加' + self.tabName, self.editInfo)
            self.addResult(addDialog)

    def addToJsonDict(self):
        pass

    def OnConfirm(self, event):
        self.infoGrid.Disable()
        self.isConfirm = True
        JsonIO.isConfirm[3 + self.childOrder] = self.isConfirm
        self.addToJsonDict()

    def OnEdit(self, event):
        self.infoGrid.Enable()
        self.isConfirm = False
        JsonIO.isConfirm[3 + self.childOrder] = self.isConfirm

    def operationResult(self, row, col, AddDialog):
        # 如果点击的是编辑操作那一列
        if col == self.gridCol:
            # 设置传入弹窗的info值
            for i in xrange(self.gridCol):
                self.info[self.editInfo[i]] = self.infoGrid.GetCellValue(row, i)
            editDialog = AddDialog(self, u'编辑第' + str(row + 1) + u'个' + self.tabName, self.editInfo)
            editDialog.setInfo(self.info)
            if editDialog.ShowModal() == wx.ID_OK:
                self.info = editDialog.getInfo()
                for i in xrange(self.gridCol):
                    self.infoGrid.SetCellValue(row, i, self.info[self.editInfo[i]])
        # 如果点击的是删除操作那一列
        elif col == self.gridCol + 1:
            self.infoGrid.DeleteRows(pos=row, numRows=1)
            self.gridRow -= 1
        else:
            pass

    def OnGridOperation(self, event):
        row = event.GetRow()
        col = event.GetCol()
        self.operationResult(row, col, AddDialog)
        # # 如果点击的是编辑操作那一列
        # if col == self.gridCol:
        #     # 设置传入弹窗的info值
        #     for i in xrange(self.gridCol):
        #         self.info[self.editInfo[i]] = self.infoGrid.GetCellValue(row, i)
        #     editDialog = AddDialog(self, u'编辑第' + str(row + 1) + u'个' + self.tabName, self.editInfo)
        #     editDialog.setInfo(self.info)
        #     if editDialog.ShowModal() == wx.ID_OK:
        #         self.info = editDialog.getInfo()
        #         for i in xrange(self.gridCol):
        #             self.infoGrid.SetCellValue(row, i, self.info[self.editInfo[i]])
        # # 如果点击的是删除操作那一列
        # elif col == self.gridCol + 1:
        #     self.infoGrid.DeleteRows(pos=row, numRows=1)
        #     self.gridRow -= 1
        # else:
        #     pass


''' 添加弹窗
'''
class AddDialog(wx.Dialog):
    def __init__(self, parent, title, editInfo, size=(600, 400), row=0, editType=None):
        super(AddDialog, self).__init__(parent, title=title, size=size)
        self.panel = wx.Panel(self)

        self.yearList = map(lambda x: str(x) + u'年', reversed(xrange(1960, 2018)))
        self.editFont = wx.Font(12, wx.SWISS, wx.NORMAL, wx.NORMAL)

        self.info = {'label': {}, 'data': {}}
        self.hSizer = list()
        self.vSizer = wx.BoxSizer(wx.VERTICAL)

        self.editInfo = editInfo
        self.infoNum = len(editInfo)

        self.editType = editType

        # for i in xrange(self.infoNum):
        #     labelName = editInfo[i]
        #     print labelName
        #     self.info['label'][labelName] = wx.StaticText(self.panel, label=labelName+u'：', size=(120, -1))
        #     self.info['data'][labelName] = wx.TextCtrl(self.panel, size=(240, -1), style=wx.TE_CENTER)
        #     self.info['data'][labelName].SetFont(self.editFont)
        #     hSizer = wx.BoxSizer(wx.HORIZONTAL)
        #     hSizer.Add(self.info['label'][labelName], 0, wx.ALIGN_CENTER)
        #     hSizer.Add(self.info['data'][labelName], 0, wx.ALIGN_CENTER)
        #     self.hSizer.append(hSizer)
        #     # self.vSizer.Add(hSizer, 1, wx.ALIGN_CENTER)
        self.defineLabelAndInput()

        self.confirmButton = wx.Button(self.panel, wx.ID_OK, label = u'确定', size = (70, 30))
        self.cancelButton = wx.Button(self.panel, wx.ID_CANCEL, label = u'取消', size = (70, 30))
        hSizer = wx.BoxSizer(wx.HORIZONTAL)
        hSizer.Add(self.confirmButton, 0, wx.ALIGN_CENTER)
        hSizer.Add(wx.StaticText(self.panel, size=(100, -1)), 0, wx.ALIGN_CENTER)
        hSizer.Add(self.cancelButton, 0, wx.ALIGN_CENTER)
        self.hSizer.append(hSizer)
        # self.vSizer.Add(hSizer, 3, wx.ALIGN_CENTER)

        self.vSizer.Add((0, 0), 1, wx.ALIGN_CENTER)
        for sizer in self.hSizer:
            self.vSizer.Add(sizer, 2, wx.ALIGN_CENTER)

        self.panel.SetSizerAndFit(self.vSizer)

    def defineLabelAndInput(self):
        for i in xrange(self.infoNum):
            labelName = self.editInfo[i]
            # print labelName
            self.info['label'][labelName] = wx.StaticText(self.panel, label=labelName + u'：', size=(120, -1))
            self.info['data'][labelName] = wx.TextCtrl(self.panel, size=(240, -1), style=wx.TE_CENTER)
            # self.info['data'][labelName].SetFont(self.editFont)
            hSizer = wx.BoxSizer(wx.HORIZONTAL)
            hSizer.Add(self.info['label'][labelName], 0, wx.ALIGN_CENTER)
            hSizer.Add(self.info['data'][labelName], 0, wx.ALIGN_CENTER)
            self.hSizer.append(hSizer)

    # 返回填写信息
    def getInfo(self):
        info = {}
        for editInfo in self.editInfo:
            labelName = editInfo
            info[labelName] = self.info['data'][labelName].GetValue()
        return info

    # 设置填写信息
    def setInfo(self, info):
        for editInfo in self.editInfo:
            labelName = editInfo
            self.info['data'][labelName].SetValue(info[labelName])